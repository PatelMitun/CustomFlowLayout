//
//  CustomFlowLayout.swift
//  CustomFlowLayout
//
//  Created by Mitun on 8/5/2019.
//

import UIKit


/**
 CustomFlowLayout.
 */
public class CustomFlowLayout: UICollectionViewLayout {
    
    /**
     Delegate.
     */
    public var delegate: CustomFlowLayoutDelegate!
    
    /// The orientation in which the `ColorSlider` is drawn.
    public enum ScrollDirection {
        /// The horizontal orientation.
        case horizontal
        
        /// The vertical orientation.
        case vertical
    }
    /**
     ScrolDirection of collectionView.
     default verical scroll direction.
     */
    public var scrollDirection: ScrollDirection = .vertical
    
    /**
     Number of columns.
     */
    public var numberOfColumns: Int = 1
    
    /**
     Number of rows for Horizontal
    */
    public var numberOfRows: Int = 1
    
    /**
     Cell padding.
     */
    public var cellPadding: CGFloat = 0
    
    private var cache = [CustomFlowLayoutAttributes]()

    private var contentHeight: CGFloat = 0
    
    private var contentWidth: CGFloat = 0
    
    private var contentDefaultHeight: CGFloat {
        get {
            let bounds = collectionView.bounds
            let insets = collectionView.contentInset
            print("contentDefalutHeight:\(bounds.height - insets.top - insets.bottom)")
            return bounds.height - insets.top - insets.bottom
        }
    }

    
    private var contentDefalutWidth: CGFloat {
        get {
            let bounds = collectionView.bounds
            let insets = collectionView.contentInset
            print("contentDefaultWidth:\(bounds.width - insets.left - insets.right)")
            return bounds.width - insets.left - insets.right
        }

    }
    
    override public var collectionViewContentSize: CGSize {
        get {
            return CGSize(
                width: contentWidth,
                height: contentHeight
            )
        }
    }
    
    override public class var layoutAttributesClass: AnyClass {
        return CustomFlowLayoutAttributes.self
    }
    
    override public var collectionView: UICollectionView {
        return super.collectionView!
    }
    
    private var numberOfSections: Int {
        return collectionView.numberOfSections
    }
    
    private func numberOfItems(inSection section: Int) -> Int {
        return collectionView.numberOfItems(inSection: section)
    }
    
    /**
     Invalidates layout.
     */
    override public func invalidateLayout() {
        cache.removeAll()
        
        if scrollDirection == .horizontal {
            contentWidth = 0
        } else {
            contentHeight = 0
        }
        
        super.invalidateLayout()
    }
    
    private func setContentHeightWidth() {
        if scrollDirection == .horizontal {
            contentHeight = contentDefaultHeight
        } else {
            contentWidth = contentDefalutWidth
        }
    }
    
    override public func prepare() {
        if cache.isEmpty {
            
            setContentHeightWidth()
            
            if scrollDirection == .vertical {
                let collumnWidth = contentWidth / CGFloat(numberOfColumns)
                let cellWidth = collumnWidth - (cellPadding * 2)
                
                var xOffsets = [CGFloat]()
                
                for collumn in 0..<numberOfColumns {
                    xOffsets.append(CGFloat(collumn) * collumnWidth)
                }
                print("xOffsets:\(xOffsets)")
                
                for section in 0..<numberOfSections {
                    let numberOfItems = self.numberOfItems(inSection: section)
                
                    var yOffsets = [CGFloat](
                        repeating: contentHeight,
                        count: numberOfColumns
                    )

                    for item in 0..<numberOfItems {
                        let indexPath = IndexPath(item: item, section: section)
                        let column = yOffsets.index(of: yOffsets.min() ?? 0) ?? 0

                        let imageHeight = delegate.collectionView(
                            collectionView: collectionView,
                            heightForImageAtIndexPath: indexPath,
                            withWidth: cellWidth
                        )
                        
//                        let imageSize = delegate.collectionView(
//                            collectionView: collectionView,
//                            sizeForImageAtIndexPath: indexPath
//                        )
                        let annotationHeight = delegate.collectionView(
                            collectionView: collectionView,
                            heightForAnnotationAtIndexPath: indexPath,
                            withWidth: cellWidth
                        )
                        let cellHeight = cellPadding + imageHeight + annotationHeight + cellPadding
                        
                        let frame = CGRect(
                            x: xOffsets[column],
                            y: yOffsets[column],
                            width: collumnWidth,
                            height: cellHeight
                        )
                        
                        let insetFrame = frame.insetBy(dx: cellPadding, dy: cellPadding)
                        let attributes = CustomFlowLayoutAttributes(
                            forCellWith: indexPath
                        )
                        attributes.frame = insetFrame
                        attributes.imageHeight = imageHeight
                        cache.append(attributes)
                        
                        contentHeight = max(contentHeight, frame.maxY)
                        yOffsets[column] = yOffsets[column] + cellHeight
                    }
                }
                
            } else {
                let rowHeight = contentHeight / CGFloat(numberOfRows)
                let cellHeight = rowHeight - (cellPadding * 2)
                
                var yOffsets = [CGFloat]()
                for row in 0..<numberOfRows {
                    yOffsets.append(CGFloat(row) * rowHeight)
                }
                
                for section in 0..<numberOfSections {
                    let numberOfItems = self.numberOfItems(inSection: section)
                    var xOffsets = [CGFloat](
                        repeating: contentWidth,
                        count: numberOfRows
                    )
                    
                    for item in 0..<numberOfItems {
                        let indexPath = IndexPath(item: item, section: section)
                        let row = xOffsets.index(of: xOffsets.min() ?? 0) ?? 0
                        let imageWidth = delegate.collectionView(
                            collectionView: collectionView,
                            heightForImageAtIndexPath: indexPath,
                            withWidth: cellHeight
                        )
                        
//                        let imageSize = delegate.collectionView(
//                            collectionView: collectionView,
//                            sizeForImageAtIndexPath: indexPath
//                        )
                        let cellWidth = cellPadding + imageWidth + cellPadding
                        let frameWidth = CGRect(
                            x: xOffsets[row],
                            y: yOffsets[row],
                            width: cellWidth,
                            height: rowHeight
                        )
                        let insetFrameWidth = frameWidth.insetBy(dx: cellPadding, dy: cellPadding)
                        let attributes = CustomFlowLayoutAttributes(
                            forCellWith: indexPath
                        )
                        attributes.frame = insetFrameWidth
                        attributes.imageWidth = imageWidth
                        cache.append(attributes)
                        contentWidth = max(contentWidth, insetFrameWidth.maxX)
                        xOffsets[row] = xOffsets[row] + cellWidth
                    }
                }
            }
        }
    }
    
    override public func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        
        var layoutAttributes = [UICollectionViewLayoutAttributes]()
        
        for attributes in cache {
            if attributes.frame.intersects(rect) {
                layoutAttributes.append(attributes)
            }
        }
        
        return layoutAttributes
    }
}

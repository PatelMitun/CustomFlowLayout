//
//  CustomFlowLayoutAttributes.swift
//  CustomFlowLayout
//
//  Created by Mitun on 8/5/2019.
//

import UIKit


/**
 CollectionViewLayoutAttributes.
 */
public class CustomFlowLayoutAttributes: UICollectionViewLayoutAttributes {
    /**
     Image height to be set to contstraint in collection view cell.
     */
    public var imageHeight: CGFloat = 0
    
    public var imageWidth: CGFloat = 0
    
    override public func copy(with zone: NSZone? = nil) -> Any {
        let copy = super.copy(with: zone) as! CustomFlowLayoutAttributes
        copy.imageHeight = imageHeight
        copy.imageWidth = imageWidth
        return copy
    }
    
    override public func isEqual(_ object: Any?) -> Bool {
        if let attributes = object as? CustomFlowLayoutAttributes {
            if attributes.imageHeight == imageHeight {
                return super.isEqual(object)
            }
        }
        return false
    }
}

//
//  FlowCell.swift
//  CustomFlowLayout
//
//  Created by Mitun Patel on 08/05/19.
//  Copyright © 2019 Mitun Patel. All rights reserved.
//

import UIKit

class FlowCell: UICollectionViewCell {

    @IBOutlet weak var image: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        image.layer.cornerRadius = 5.0
    }
    
    func configCell(image: UIImage) {
        self.image.image = image
    }
    override func prepareForReuse() {
        super.prepareForReuse()
    }

}

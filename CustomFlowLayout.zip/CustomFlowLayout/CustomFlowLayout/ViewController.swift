//
//  ViewController.swift
//  CustomFlowLayout
//
//  Created by Mitun Patel on 08/05/19.
//  Copyright © 2019 Mitun Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    var images: [UIImage] = [#imageLiteral(resourceName: "cat"), #imageLiteral(resourceName: "bigben_river"), #imageLiteral(resourceName: "4"), #imageLiteral(resourceName: "5"), #imageLiteral(resourceName: "12"), #imageLiteral(resourceName: "cat"), #imageLiteral(resourceName: "6"), #imageLiteral(resourceName: "city"), #imageLiteral(resourceName: "9"), #imageLiteral(resourceName: "2"), #imageLiteral(resourceName: "bridge"), #imageLiteral(resourceName: "bw_new_york"), #imageLiteral(resourceName: "11"), #imageLiteral(resourceName: "8"), #imageLiteral(resourceName: "13"), #imageLiteral(resourceName: "4")]
    override func viewDidLoad() {
        super.viewDidLoad()
        configCollection()
    }
    
    //MARK: private
    private func configCollection() {
        self.collectionView.register(UINib(nibName: "FlowCell", bundle: nil), forCellWithReuseIdentifier: "FlowCell")
        setupCollectionViewInsets()
        setupLayout()
        self.collectionView.reloadData()
    }
    
    private func setupCollectionViewInsets() {
        collectionView.contentInset = UIEdgeInsets(
            top: 5,
            left: 5,
            bottom: 5,
            right: 5
        )
    }
    
    private func setupLayout() {
        let layout: CustomFlowLayout = {
            if let layout = collectionView.collectionViewLayout as? CustomFlowLayout {
                return layout
            }
            let layout = CustomFlowLayout()
            
            collectionView?.collectionViewLayout = layout
            
            return layout
        }()
        layout.delegate = self
        layout.cellPadding = 5
        
        //vertical scroll, set numberOfColumn value
        layout.scrollDirection = .vertical
        layout.numberOfColumns = 2
        
        //horizontal scroll, set numberOfRows value
        layout.scrollDirection = .horizontal
        layout.numberOfRows = 2
    }

}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FlowCell", for: indexPath) as! FlowCell
        cell.configCell(image: images[indexPath.row])
        return cell
    }
}
extension ViewController: CustomFlowLayoutDelegate {
    func collectionView(collectionView: UICollectionView,
                        heightForImageAtIndexPath indexPath: IndexPath,
                        withWidth: CGFloat) -> CGFloat {
        let image = images[indexPath.item]
        return image.height(forWidth: withWidth)
    }
    
    func collectionView(collectionView: UICollectionView, sizeForImageAtIndexPath indexPath: IndexPath) -> CGSize {
        return CGSize.zero
    }
    
    func collectionView(collectionView: UICollectionView,
                        heightForAnnotationAtIndexPath indexPath: IndexPath,
                        withWidth: CGFloat) -> CGFloat {
        return 0
    }
}

